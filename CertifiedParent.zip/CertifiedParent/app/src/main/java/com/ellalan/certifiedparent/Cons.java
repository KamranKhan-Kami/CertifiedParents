package com.ellalan.certifiedparent;

/**
 * Created by JEFRI on 5/12/2017.
 */

public class Cons {
    public static String QUESTION = "question";
    public static String STATUS = "status";
}
