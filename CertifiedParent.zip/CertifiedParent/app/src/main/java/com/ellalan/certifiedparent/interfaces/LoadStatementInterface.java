package com.ellalan.certifiedparent.interfaces;

/**
 * Created by CH_M_USMAN on 28-Sep-17.
 */

public interface LoadStatementInterface {
    void LoadNextChildPsychologyStatement();
    void LoadNextParentPsychologyStatement();
    void LoadNextParentingTipsStatement();
    void LoadNextKnowFactsStatement();

    void LoadPreviousChildPsychologyStatement();
    void LoadPreviousParentPsychologyStatement();
    void LoadPreviousParentingTipsStatement();
    void LoadPreviousKnowFactsStatement();

    void ChangeHomeFragment();
}
