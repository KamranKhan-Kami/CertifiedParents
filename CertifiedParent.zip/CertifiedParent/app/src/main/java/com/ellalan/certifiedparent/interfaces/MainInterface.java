package com.ellalan.certifiedparent.interfaces;

/**
 * Created by JEFRI on 5/12/2017.
 */

public interface MainInterface {
    void LoadNext();
    void UpdateResult(Boolean status);

}
