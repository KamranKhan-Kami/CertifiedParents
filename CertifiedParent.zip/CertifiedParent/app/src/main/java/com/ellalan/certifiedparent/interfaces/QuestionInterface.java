package com.ellalan.certifiedparent.interfaces;

/**
 *
 * Created by Farhan on 7/21/2017.
 */

public interface QuestionInterface {
    void MoveToAnswer(boolean answerCorrect);
}
