package com.ellalan.certifiedparent.interfaces;

/**
 * Created by Farhan on 7/22/2017.
 */

public interface TestCompleteInterface {
    void continueToCertificate();
}
