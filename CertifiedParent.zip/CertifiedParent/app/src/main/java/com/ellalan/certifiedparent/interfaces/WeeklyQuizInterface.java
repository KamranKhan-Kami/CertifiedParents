package com.ellalan.certifiedparent.interfaces;

/**
 * Created by CH_M_USMAN on 02-Oct-17.
 */

public interface WeeklyQuizInterface {
    void LoadQuestion();
    void LoadAnswer(boolean result);
    void UpdateWeeklyQuizResult(boolean re);

    void ChallengeAParent();
}
