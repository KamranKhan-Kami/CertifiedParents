package com.ellalan.certifiedparent.model;

/**
 * Created by Farhan on 7/30/2017.
 */

public class Quote {
    private String quote;
    private String person;

    public String getQuote() {
        return quote;
    }

    public void setQuote(String quote) {
        this.quote = quote;
    }

    public String getPerson() {
        return person;
    }

    public void setPerson(String person) {
        this.person = person;
    }
}
